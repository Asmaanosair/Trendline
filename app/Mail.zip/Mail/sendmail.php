<?php

namespace App\Mail;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\HTTP\Request;

class sendmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build(Request $request)
    {
        
        
            foreach ($request->file('file') as $media) {
            if (!empty($media)) {
                $destinationPath = 'files';
                $filename = $media->getClientOriginalName();
                $media->move($destinationPath, $filename);
                $files[]= $filename;
            }
                

        }
          return $this->view('mail2',['msg'=>$request->msg,'name'=>$request->name,'phone'=>$request->phone,'file'=>$files,
            'mail'=>$request->mail])->to('hr@mahergroup-eg.com')->from($request->mail)->subject('Maher Group');
     
         
       
    }
}
